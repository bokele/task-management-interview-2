<div class="p-4">
    <table class="w-full  p-4 table-auto border-collapse border-2 border-gray-500 mb-4">
        <thead>
            <tr>
                <th class="border border-gray-400 px-4 py-2 text-gray-800">#</th>

                <th class="border border-gray-400 px-4 py-2 text-gray-800">Project</th>
                <th class="border border-gray-400 px-4 py-2 text-gray-800">Task</th>
                <th class="border border-gray-400 px-4 py-2 text-gray-800">Priority</th>
                <th class="border border-gray-400 px-4 py-2 text-gray-800">Actions</th>
            </tr>
        </thead>
        <tbody wire:sortable="updateOrder">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr wire:sortable.handle wire:sortable.item="<?php echo e($task->id); ?>" wire:key="task-<?php echo e($task->id); ?>">

                    <td class="border border-gray-400 px-4 py-2"><?php echo e($task->priority); ?></td>
                    <td class="border border-gray-400 px-4 py-2"><?php echo e(Str::title($task->project->name)); ?></td>
                    <td class="border border-gray-400 px-4 py-2"><?php echo e(Str::title($task->name)); ?></td>
                    <td class="border border-gray-400 px-4 py-2"><?php echo e($loop->iteration); ?></td>

                    <td class="border border-gray-400 px-4 py-2">
                        <a href="<?php echo e(route('tasks.edit', $task->id)); ?>"
                            class=" justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
                            Edit
                        </a>
                        <button wire:click="delete(<?php echo e($task->id); ?>)"
                            wire:confirm="Are you sure you want to delete this project?"
                            class="ml-2 justify-center rounded-md bg-red-600 px-3 py-1 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-red-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600">
                            Delete
                        </button>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td class="border border-gray-400 px-4 py-2 text-center" colspan="5"> Not Data, add a task</td>


                </tr>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->




        </tbody>
    </table>

</div>
<?php /**PATH /Users/bokelewakizafranck/Herd/task-management/resources/views/livewire/task/index.blade.php ENDPATH**/ ?>